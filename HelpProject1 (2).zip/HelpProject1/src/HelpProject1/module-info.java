module HelpProject1 {
    requires javafx.controls;
    requires javafx.fxml;
	//requires junit;
    exports  HelpProject1.application; 
}
