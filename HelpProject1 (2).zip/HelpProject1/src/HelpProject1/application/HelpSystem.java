package HelpProject1.application;

import java.util.*;
import java.time.LocalDateTime;
import java.io.Serializable;
import java.util.Base64;

public class HelpSystem {
    private Map<String, User> users;
    private List<HelpArticle> articles;
    private boolean hasAdmin = false;
    private Map<String, Set<User.Role>> invitationCodes = new HashMap<>();
    private User currentUser;
    private Map<String, Group> groups; // Groups management
    private Map<String, List<String>> studentSearches; // To track student searches
    private Map<String, List<String>> studentMessages; // To track student messages
    private Map<String, List<String>> genericMessages; // Generic messages from students
    private Map<String, List<String>> specificMessages; // Specific messages from students

    public HelpSystem() {
        users = FileManager.loadUsers();
        articles = FileManager.loadArticles();
        groups = FileManager.loadGroups(); // Load groups from file
        studentSearches = new HashMap<>();
        studentMessages = new HashMap<>();
        genericMessages = new HashMap<>();
        specificMessages = new HashMap<>();

        // Check if any existing user is an admin
        for (User user : users.values()) {
            if (user.getRoles().contains(User.Role.ADMIN)) {
                hasAdmin = true;
                break;
            }
        }
        if (!hasAdmin) {
            createInitialAdmin();
        }

        // Update nextId in HelpArticle class to ensure unique IDs
        updateNextArticleId();
    }

    private void updateNextArticleId() {
        long maxId = 0;
        for (HelpArticle article : articles) {
            if (article.getId() > maxId) {
                maxId = article.getId();
            }
        }
        HelpArticle.setNextId(maxId + 1);
    }

    public void createInitialAdmin() {
        System.out.println("No admin found. The first user to register will be assigned as Admin.");
    }

    public void addUser(User user) {
        if (user.getRoles().contains(User.Role.ADMIN) && !hasAdmin) {
            hasAdmin = true;
        }
        users.put(user.getUsername(), user);
        FileManager.saveUsers(users);
    }

    public boolean hasAdmin() {
        return hasAdmin;
    }

    public Map<String, User> getUsers() {
        return users;
    }

    public User getUser(String username) {
        return users.get(username);
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public User getCurrentUser() {
        return this.currentUser;
    }

    public void updateUser(User user) {
        users.put(user.getUsername(), user);
        FileManager.saveUsers(users);
    }

    public void deleteUser(String username) {
        if (users.containsKey(username)) {
            users.remove(username);
            FileManager.saveUsers(users);
        }
    }

    public void inviteUser(String invitationCode, Set<User.Role> roles) {
        invitationCodes.put(invitationCode, roles);
        System.out.println("Invitation code generated: " + invitationCode + " for roles: " + roles.toString());
    }

    public boolean validateInvitationCode(String code) {
        return invitationCodes.containsKey(code);
    }

    public Set<User.Role> getRolesForInvitationCode(String code) {
        return invitationCodes.get(code);
    }

    public void resetPassword(String username, String tempPassword) {
        User user = users.get(username);
        if (user != null) {
            user.setOneTimePassword(true);
            user.setOtpExpiry(LocalDateTime.now().plusHours(24));
            FileManager.saveUsers(users); // Save the updated user
        }
    }

    // Article management methods
    public void addArticle(HelpArticle article) {
        // Assign a unique ID automatically
        article.setId(HelpArticle.getNextId());
        HelpArticle.incrementNextId();

        articles.add(article);
        FileManager.saveArticles(articles);
    }

    public HelpArticle getArticleById(long id) {
        for (HelpArticle article : articles) {
            if (article.getId() == id) {
                return article;
            }
        }
        return null;
    }

    public boolean deleteArticleById(long id) {
        Iterator<HelpArticle> iterator = articles.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getId() == id) {
                iterator.remove();
                FileManager.saveArticles(articles);
                return true;
            }
        }
        return false;
    }

    public void updateArticle(HelpArticle updatedArticle) {
        for (int i = 0; i < articles.size(); i++) {
            if (articles.get(i).getId() == updatedArticle.getId()) {
                articles.set(i, updatedArticle);
                FileManager.saveArticles(articles);
                break;
            }
        }
    }

    public List<HelpArticle> getArticles() {
        return articles;
    }

    public List<HelpArticle> getArticlesByGroups(List<String> groupNames) {
        List<HelpArticle> result = new ArrayList<>();
        for (HelpArticle article : articles) {
            for (String group : groupNames) {
                if (article.getGroups().contains(group.trim())) {
                    result.add(article);
                    break; // Avoid duplicates
                }
            }
        }
        return result;
    }

    // Backup and restore methods
    public void backupArticles(String filename, List<String> groupNames) {
        List<HelpArticle> articlesToBackup;
        if (groupNames == null || groupNames.isEmpty()) {
            articlesToBackup = new ArrayList<>(articles);
        } else {
            articlesToBackup = getArticlesByGroups(groupNames);
        }
        FileManager.backupArticles(articlesToBackup, filename);
    }

    public void restoreArticles(String filename, boolean removeExisting) {
        List<HelpArticle> restoredArticles = FileManager.loadArticlesFromBackup(filename);
        if (removeExisting) {
            articles.clear();
        }
        articles.addAll(restoredArticles);
        FileManager.saveArticles(articles);
    }

    public void backupGroups(String filename) {
        FileManager.backupGroups(groups, filename);
    }

    public void restoreGroups(String filename, boolean removeExisting) {
        Map<String, Group> restoredGroups = FileManager.loadGroupsFromBackup(filename);
        if (removeExisting) {
            groups.clear();
        }
        groups.putAll(restoredGroups);
        FileManager.saveGroups(groups);
    }

    // Search articles with additional parameters
    public List<HelpArticle> searchArticles(String keyword, String level, List<String> groupNames, User user) {
        List<HelpArticle> results = new ArrayList<>();
        String lowerKeyword = keyword.toLowerCase();

        for (HelpArticle article : articles) {
            // Check if the article matches the search criteria
            boolean matchesKeyword = article.getTitle().toLowerCase().contains(lowerKeyword) ||
                    article.getDescription().toLowerCase().contains(lowerKeyword) ||
                    article.getKeywords().stream().anyMatch(k -> k.toLowerCase().contains(lowerKeyword));

            boolean matchesLevel = level.equals("All") || article.getLevel().equalsIgnoreCase(level);

            boolean matchesGroup = groupNames.isEmpty() || groupNames.stream().anyMatch(g -> article.getGroups().contains(g.trim()));

            boolean hasAccess = userHasAccessToArticle(user, article);

            if (matchesKeyword && matchesLevel && matchesGroup && hasAccess) {
                results.add(article);
            }
        }
        return results;
    }


    // Group management methods
    public void createGroup(String groupName, boolean isSpecialAccessGroup, User creator) {
        if (!groups.containsKey(groupName)) {
            Group group = new Group(groupName, isSpecialAccessGroup);
            groups.put(groupName, group);

            // Add creator as group admin if creator is not null
            if (creator != null) {
                group.addGroupAdmin(creator);
            }

            // Add all admins as group admins
            for (User user : users.values()) {
                if (user.getRoles().contains(User.Role.ADMIN)) {
                    group.addGroupAdmin(user);
                }
            }
            FileManager.saveGroups(groups);
        } else {
            System.out.println("Group already exists.");
        }
    }




    public void addArticleToGroup(String groupName, HelpArticle article) {
        Group group = groups.get(groupName);
        if (group != null) {
            group.addArticle(article);
            article.addGroup(groupName);
            if (group.isSpecialAccessGroup()) {
                article.setIsEncrypted(true);
                article.setContent(article.getContent(null), group.getEncryptionKey());
            }
            FileManager.saveArticles(articles);
            FileManager.saveGroups(groups);
        }
    }

    public void addUserToGroup(String groupName, User user, User.GroupRole role) {
        Group group = groups.get(groupName);
        if (group != null) {
            if (group.isSpecialAccessGroup()) {
                if (role == User.GroupRole.INSTRUCTOR) {
                    if (group.groupAdmins.isEmpty()) {
                        // First instructor gets admin rights and view permissions
                        group.addGroupAdmin(user);
                    } else {
                        // Add instructor with view rights only
                        group.addInstructorWithViewRights(user);
                    }
                } else if (role == User.GroupRole.STUDENT) {
                    group.addStudentWithViewRights(user);
                } else if (role == User.GroupRole.ADMIN) {
                    // Admins do not automatically have access; need explicit permission
                    group.addGroupAdmin(user);
                }
            } else {
                // For general groups
                if (role == User.GroupRole.ADMIN) {
                    group.addGroupAdmin(user);
                } else if (role == User.GroupRole.INSTRUCTOR) {
                    group.addInstructor(user);
                } else if (role == User.GroupRole.STUDENT) {
                    group.addStudent(user);
                }
            }
            FileManager.saveUsers(users);
            FileManager.saveGroups(groups);
        }
    }

    public boolean userHasAccessToArticle(User user, HelpArticle article) {
        if (article.getGroups().isEmpty()) {
            // Public article, all users have access
            return true;
        }
        for (String groupName : article.getGroups()) {
            Group group = groups.get(groupName);
            if (group != null) {
                if (group.userHasViewPermission(user)) {
                    return true;
                }
            }
        }
        return false;
    }

    // Student messages and searches
    public void addStudentSearch(String username, String searchQuery) {
        studentSearches.computeIfAbsent(username, k -> new ArrayList<>()).add(searchQuery);
    }

    public void addStudentMessage(String username, String message) {
        studentMessages.computeIfAbsent(username, k -> new ArrayList<>()).add(message);
    }

    public List<String> getStudentSearches(String username) {
        return studentSearches.getOrDefault(username, new ArrayList<>());
    }
    public Map<String, List<String>> getStudentSearches() {
        return studentSearches;
    }
    public List<String> getStudentMessages(String username) {
        return studentMessages.getOrDefault(username, new ArrayList<>());
    }

    // Messaging system
    public void addGenericMessage(String username, String message) {
        genericMessages.computeIfAbsent(username, k -> new ArrayList<>()).add(message);
    }

    public void addSpecificMessage(String username, long articleId, String message) {
        // Store messages with the article ID and message content
        String fullMessage = "Article ID: " + articleId + " - " + message;
        specificMessages.computeIfAbsent(username, k -> new ArrayList<>()).add(fullMessage);
    }


    public Map<String, List<String>> getGenericMessages() {
        return genericMessages;
    }

    public Map<String, List<String>> getSpecificMessages() {
        return specificMessages;
    }
    

    // Inner Group class
    public static class Group implements Serializable {
        private static final long serialVersionUID = 1L;
        private String name;
        private List<HelpArticle> articles;
        private Set<String> groupAdmins;
        private Set<String> instructorsWithViewRights;
        private Set<String> studentsWithViewRights;
        private Set<String> instructors; // For general groups
        private Set<String> students;    // For general groups
        private String encryptionKey;
        private boolean isSpecialAccessGroup;

        public Group(String name, boolean isSpecialAccessGroup) {
            this.name = name;
            this.articles = new ArrayList<>();
            this.groupAdmins = new HashSet<>();
            this.instructorsWithViewRights = new HashSet<>();
            this.studentsWithViewRights = new HashSet<>();
            this.instructors = new HashSet<>();
            this.students = new HashSet<>();
            this.isSpecialAccessGroup = isSpecialAccessGroup;
            if (isSpecialAccessGroup) {
                this.encryptionKey = generateEncryptionKey();
            } else {
                this.encryptionKey = null;
            }
        }

        // Methods to manage group
        public void addArticle(HelpArticle article) {
            articles.add(article);
        }

        public void addGroupAdmin(User user) {
            String username = user.getUsername();
            groupAdmins.add(username);
            user.addGroupRole(name, User.GroupRole.ADMIN);
        }

        public void removeGroupAdmin(User user) {
            String username = user.getUsername();
            if (canRemoveAdmin(user)) {
                groupAdmins.remove(username);
                user.removeGroupRole(name);
            } else {
                System.out.println("Cannot remove admin rights from " + username +
                        " as it would leave the group without an admin.");
            }
        }

        public void addInstructorWithViewRights(User user) {
            String username = user.getUsername();
            instructorsWithViewRights.add(username);
            user.addGroupRole(name, User.GroupRole.INSTRUCTOR);
        }

        public void addStudentWithViewRights(User user) {
            String username = user.getUsername();
            studentsWithViewRights.add(username);
            user.addGroupRole(name, User.GroupRole.STUDENT);
        }

        public void addInstructor(User user) {
            String username = user.getUsername();
            instructors.add(username);
            user.addGroupRole(name, User.GroupRole.INSTRUCTOR);
        }

        public void addStudent(User user) {
            String username = user.getUsername();
            students.add(username);
            user.addGroupRole(name, User.GroupRole.STUDENT);
        }

        public boolean userHasViewPermission(User user) {
            String username = user.getUsername();
            if (isSpecialAccessGroup) {
                return groupAdmins.contains(username) ||
                        instructorsWithViewRights.contains(username) ||
                        studentsWithViewRights.contains(username);
            } else {
                // For general groups, all group members have view rights
                return groupAdmins.contains(username) ||
                        instructors.contains(username) ||
                        students.contains(username);
            }
        }

        public boolean isGroupAdmin(User user) {
            return groupAdmins.contains(user.getUsername()) || user.getRoles().contains(User.Role.ADMIN);
        }


        public boolean canRemoveAdmin(User user) {
            return groupAdmins.size() > 1 || !groupAdmins.contains(user.getUsername());
        }

        public boolean hasAdmin() {
            return !groupAdmins.isEmpty();
        }

        public String getEncryptionKey() {
            return encryptionKey;
        }

        public boolean isSpecialAccessGroup() {
            return isSpecialAccessGroup;
        }

        private String generateEncryptionKey() {
            // Generate a simple key for demonstration purposes
            return Base64.getEncoder().encodeToString(name.getBytes());
        }

        // Getters and setters for serialization
        public String getName() {
            return name;
        }

        public List<HelpArticle> getArticles() {
            return articles;
        }

        public Set<String> getGroupAdmins() {
            return groupAdmins;
        }

        public Set<String> getInstructorsWithViewRights() {
            return instructorsWithViewRights;
        }

        public Set<String> getStudentsWithViewRights() {
            return studentsWithViewRights;
        }

        public Set<String> getInstructors() {
            return instructors;
        }
        

        public Set<String> getStudents() {
            return students;
        }
    }

    public Map<String, Group> getGroups() {
        return groups;
    }

    public Group getGroup(String groupName) {
        return groups.get(groupName);
    }
}
