package HelpProject1.application;

import java.io.Serializable;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class HelpArticle implements Serializable {
    private static final long serialVersionUID = 1L;
    private static long nextId = 1; // For unique ID generation

    private long id;
    private String title;
    private String description;
    private List<String> keywords;
    private byte[] content; // Changed from String to byte[] for encryption
    private String level;
    private List<String> groups;
    private boolean isEncrypted; // Indicates if content is encrypted

    // Constructor without ID (for new articles)
    public HelpArticle(String title, String description, List<String> keywords, String content, String level, boolean isEncrypted) {
        //this.id = nextId++; // Assign a unique ID
        this.title = title;
        this.description = description;
        this.keywords = keywords;
        this.level = level;
        this.groups = new ArrayList<>();
        this.isEncrypted = isEncrypted;
        if (isEncrypted) {
            // Content will be encrypted later using the group's key
            this.content = null;
        } else {
            this.content = content.getBytes();
        }
    }

    // Getter methods
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public static long getNextId() {
        return nextId;
    }

    public static void setNextId(long nextId) {
        HelpArticle.nextId = nextId;
    }

    public static void incrementNextId() {
        nextId++;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getKeywords() {
        return keywords;
    }

    public String getLevel() {
        return level;
    }

    public List<String> getGroups() {
        return groups;
    }

    public boolean isEncrypted() {
        return isEncrypted;
    }

    // Setter methods
    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setKeywords(List<String> keywords) {
        this.keywords = keywords;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setGroups(List<String> groups) {
        this.groups = groups;
    }

    public void setIsEncrypted(boolean isEncrypted) {
        this.isEncrypted = isEncrypted;
    }

    // Methods to add or remove groups
    public void addGroup(String group) {
        if (!groups.contains(group)) {
            groups.add(group);
        }
    }

    public void removeGroup(String group) {
        groups.remove(group);
    }

    // Encryption and decryption methods
    public void setContent(String content, String key) {
        if (isEncrypted) {
            this.content = encryptContent(content, key);
        } else {
            this.content = content.getBytes();
        }
    }

    public String getContent(String key) {
        if (isEncrypted) {
            return decryptContent(content, key);
        } else {
            return new String(content);
        }
    }

    private byte[] encryptContent(String content, String key) {
        try {
            SecretKey secretKey = new SecretKeySpec(key.getBytes(), 0, 16, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            return cipher.doFinal(content.getBytes());
        } catch (Exception e) {
            throw new RuntimeException("Error while encrypting content", e);
        }
    }

    private String decryptContent(byte[] encryptedContent, String key) {
        try {
            SecretKey secretKey = new SecretKeySpec(key.getBytes(), 0, 16, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decrypted = cipher.doFinal(encryptedContent);
            return new String(decrypted);
        } catch (Exception e) {
            throw new RuntimeException("Error while decrypting content", e);
        }
    }
}
