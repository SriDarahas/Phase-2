package HelpProject1.application;

import javafx.scene.Scene;

import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.application.Platform;
import java.util.UUID;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import java.util.Map;
import java.util.HashMap;

public class HelpSystemUI {
    private Stage stage;
    private HelpSystem helpSystem;
    
    private AuthService authService;

    public HelpSystemUI(Stage stage) {
        this.stage = stage;
        this.helpSystem = new HelpSystem();
        this.authService = new AuthService(helpSystem);
    }

    public void show() {
        showWelcomeScreen();
    }
    
    private void showStudentDashboard(User user) {
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label welcomeLabel = new Label("Welcome, " + user.getPreferredName() + "!");
        welcomeLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Button searchArticlesButton = new Button("Search Help Articles");
        Button viewArticlesButton = new Button("View Articles");
        Button viewSearchHistoryButton = new Button("View Search History"); // New button
        Button sendGenericMessageButton = new Button("Send Generic Message");
        Button sendSpecificMessageButton = new Button("Send Specific Message");
        Button logoutButton = new Button("Logout");

        // Event handlers
        searchArticlesButton.setOnAction(e -> showStudentSearchArticles(user));
        viewSearchHistoryButton.setOnAction(e -> showSearchHistoryScreen(user)); // New event handler
        sendGenericMessageButton.setOnAction(e -> showSendGenericMessageScreen(user));
        sendSpecificMessageButton.setOnAction(e -> showSendSpecificMessageScreen(user));
        logoutButton.setOnAction(e -> {
            helpSystem.setCurrentUser(null);
            showLoginScreen();
        });

        // Group message buttons in HBox
        HBox messageButtonsBox = new HBox(10);
        messageButtonsBox.setAlignment(Pos.CENTER);
        messageButtonsBox.getChildren().addAll(sendGenericMessageButton, sendSpecificMessageButton);

        root.getChildren().addAll(
            welcomeLabel,
            searchArticlesButton,
            viewSearchHistoryButton, // Add the new button to the layout
            messageButtonsBox,
            logoutButton
        );

        Scene scene = new Scene(root, 400, 600);
        stage.setScene(scene);
        stage.show();
    }

    private void showSearchHistoryScreen(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Your Search History");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        ListView<String> searchHistoryListView = new ListView<>();
        searchHistoryListView.setPrefHeight(400);

        // Get the student's search history
        List<String> searchHistory = helpSystem.getStudentSearches().get(user.getUsername());

        if (searchHistory != null && !searchHistory.isEmpty()) {
            searchHistoryListView.getItems().addAll(searchHistory);
        } else {
            searchHistoryListView.getItems().add("No search history found.");
        }

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> showStudentDashboard(user));

        root.getChildren().addAll(titleLabel, searchHistoryListView, backButton);
        Scene scene = new Scene(root, 500, 500);
        stage.setScene(scene);
        stage.show();
    }

    private void showStudentSearchArticlesWithQuery(User user, String query) {
        // Similar to showStudentSearchArticles but pre-fill the keyword field
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Search Help Articles");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField keywordField = new TextField(query); // Pre-fill with the selected query
        keywordField.setPromptText("Enter keyword(s)");

        // ... rest of the code from showStudentSearchArticles ...

        // Set up the scene and show it
        Scene scene = new Scene(root, 600, 600);
        stage.setScene(scene);
        stage.show();
    }


    private void showWelcomeScreen() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label welcomeLabel = new Label("Welcome to the CSE 360 Help System");

        Button loginButton = new Button("Login");
        Button signupButton = new Button("Signup");

        // Button actions
        loginButton.setOnAction(e -> showLoginScreen());

        signupButton.setOnAction(e -> {
            if (!helpSystem.hasAdmin()) {
                // No admin exists, direct to admin signup
                showAdminSignup();
            } else {
                // Admin exists, direct to regular signup
                showSignUpScreen(new HashSet<>());
            }
        });

        FlowPane buttons = new FlowPane(10, 0);
        buttons.setAlignment(Pos.CENTER);
        buttons.getChildren().addAll(loginButton, signupButton);

        root.getChildren().addAll(welcomeLabel, buttons);
        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void showAdminSignup() {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label prompt = new Label("Create Admin Account");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        Button createAdminButton = new Button("Create Admin");

        createAdminButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();
            String confirmPassword = confirmPasswordField.getText().trim();
            String email = emailField.getText().trim();

            if (username.isEmpty() || password.isEmpty() || email.isEmpty() || confirmPassword.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "All fields are required.").showAndWait();
                return;
            }

            if (!password.equals(confirmPassword)) {
                new Alert(Alert.AlertType.ERROR, "Passwords do not match.").showAndWait();
                return;
            }

            if (helpSystem.getUser(username) != null) {
                new Alert(Alert.AlertType.ERROR, "Username already exists.").showAndWait();
                return;
            }

            byte[] passwordHash = authService.hashPassword(password);
            Admin admin = new Admin(email, username, passwordHash, "Admin", "User");

            helpSystem.addUser(admin);

            new Alert(Alert.AlertType.INFORMATION, "Admin account created successfully!").showAndWait();
            showLoginScreen();
        });

        root.getChildren().addAll(prompt, usernameField, passwordField, confirmPasswordField, emailField, createAdminButton);
        Scene scene = new Scene(root, 400, 400);
        stage.setScene(scene);
        stage.show();
    }

    private void showLoginScreen() {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label welcomeLabel = new Label("Login to the CSE 360 Help System");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        TextField invitationCodeField = new TextField();
        invitationCodeField.setPromptText("Invitation Code (if any)");

        Button loginButton = new Button("Login");
        Button signupButton = new Button("Signup with Code");
        Button resetPasswordButton = new Button("Reset Password");

        FlowPane buttons = new FlowPane(10, 0);
        buttons.setAlignment(Pos.CENTER);
        buttons.getChildren().addAll(loginButton, signupButton, resetPasswordButton);

        loginButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            if (username.isEmpty() || password.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Both fields are required.").showAndWait();
                return;
            }

            boolean isAuthenticated = authService.authenticate(username, password);

            if (isAuthenticated) {
                User user = helpSystem.getUser(username);
                helpSystem.setCurrentUser(user);
                if (user.isFirstLogin()) {
                    showFinishAccountSetup(user);
                } else {
                    new Alert(Alert.AlertType.INFORMATION, "Login successful!").showAndWait();
                    // Check user role and show appropriate dashboard
                    if (user.getRoles().contains(User.Role.STUDENT)) {
                        showStudentDashboard(user);
                    } else {
                        showDashboard(user);
                    }
                }
            } else {
                new Alert(Alert.AlertType.ERROR, "Invalid credentials.").showAndWait();
            }
        });

        signupButton.setOnAction(e -> {
            String invitationCode = invitationCodeField.getText().trim();
            if (helpSystem.validateInvitationCode(invitationCode)) {
                Set<User.Role> roles = helpSystem.getRolesForInvitationCode(invitationCode);
                showSignUpScreen(roles);
            } else {
                new Alert(Alert.AlertType.ERROR, "Invalid invitation code.").showAndWait();
            }
        });

        resetPasswordButton.setOnAction(e -> showResetPasswordRequestScreen());

        root.getChildren().addAll(welcomeLabel, usernameField, passwordField, invitationCodeField, buttons);
        Scene scene = new Scene(root, 400, 400);
        stage.setScene(scene);
        stage.show();
    }

    private void showSignUpScreen(Set<User.Role> roles) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label prompt = new Label("Create New Account");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        Button createAccountButton = new Button("Create Account");

        createAccountButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();
            String confirmPassword = confirmPasswordField.getText().trim();
            String email = emailField.getText().trim();

            if (username.isEmpty() || password.isEmpty() || email.isEmpty() || confirmPassword.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "All fields are required.").showAndWait();
                return;
            }

            if (!password.equals(confirmPassword)) {
                new Alert(Alert.AlertType.ERROR, "Passwords do not match.").showAndWait();
                return;
            }

            if (helpSystem.getUser(username) != null) {
                new Alert(Alert.AlertType.ERROR, "Username already exists.").showAndWait();
                return;
            }

            byte[] passwordHash = authService.hashPassword(password);
            User newUser = new User(email, username, passwordHash, "FirstName", "LastName");
            roles.forEach(newUser::addRole);
            helpSystem.addUser(newUser);

            new Alert(Alert.AlertType.INFORMATION, "Account created successfully!").showAndWait();
            showLoginScreen();
        });

        root.getChildren().addAll(prompt, usernameField, passwordField, confirmPasswordField, emailField, createAccountButton);
        Scene scene = new Scene(root, 400, 400);
        stage.setScene(scene);
        stage.show();
    }

    private void showFinishAccountSetup(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label prompt = new Label("Finish Setting Up Your Account");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First Name");

        TextField middleNameField = new TextField();
        middleNameField.setPromptText("Middle Name");

        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");

        TextField preferredNameField = new TextField();
        preferredNameField.setPromptText("Preferred Name (optional)");

        Button completeSetupButton = new Button("Complete Setup");

        completeSetupButton.setOnAction(e -> {
            String email = emailField.getText().trim();
            String firstName = firstNameField.getText().trim();
            String middleName = middleNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String preferredName = preferredNameField.getText().trim();

            if (email.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Email, first name, and last name are required.").showAndWait();
                return;
            }

            user.completeProfile(email, firstName, middleName, lastName, preferredName);
            helpSystem.updateUser(user);

            new Alert(Alert.AlertType.INFORMATION, "Account setup complete!").showAndWait();
            if (user.getRoles().contains(User.Role.STUDENT)) {
                showStudentDashboard(user);
            } else {
                showDashboard(user);
            }
        });

        root.getChildren().addAll(prompt, emailField, firstNameField, middleNameField, lastNameField, preferredNameField, completeSetupButton);
        Scene scene = new Scene(root, 400, 400);
        stage.setScene(scene);
        stage.show();
    }
    
    private void showManageGroups(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_LEFT);

        Label titleLabel = new Label("Manage Groups");

        ListView<String> groupListView = new ListView<>();
        updateGroupListView(groupListView);

        Button createGroupButton = new Button("Create Group");
        Button editGroupButton = new Button("Edit Group");
        Button deleteGroupButton = new Button("Delete Group");
        Button backButton = new Button("Back");

        HBox buttonBox = new HBox(10);
        buttonBox.getChildren().addAll(createGroupButton, editGroupButton, deleteGroupButton, backButton);

        // Adjust button visibility based on user roles
        createGroupButton.setVisible(true); // Any user can create a group

        if (user.getRoles().contains(User.Role.INSTRUCTOR) || user.getRoles().contains(User.Role.ADMIN)) {
            editGroupButton.setVisible(true);
            deleteGroupButton.setVisible(true);
        } else {
            editGroupButton.setVisible(false);
            deleteGroupButton.setVisible(false);
        }

        createGroupButton.setOnAction(e -> showCreateGroupScreen(user, groupListView));
        editGroupButton.setOnAction(e -> {
            String selectedGroup = groupListView.getSelectionModel().getSelectedItem();
            if (selectedGroup == null) {
                new Alert(Alert.AlertType.ERROR, "Please select a group to edit.").showAndWait();
                return;
            }
            showEditGroupScreen(user, selectedGroup, groupListView);
        });
        deleteGroupButton.setOnAction(e -> {
            String selectedGroup = groupListView.getSelectionModel().getSelectedItem();
            if (selectedGroup == null) {
                new Alert(Alert.AlertType.ERROR, "Please select a group to delete.").showAndWait();
                return;
            }
            handleDeleteGroup(user, selectedGroup, groupListView);
        });
        backButton.setOnAction(e -> {
            if (user.getRoles().contains(User.Role.STUDENT)) {
                showStudentDashboard(user);
            } else {
                showDashboard(user);
            }
        });

        root.getChildren().addAll(titleLabel, groupListView, buttonBox);
        Scene scene = new Scene(root, 500, 500);
        stage.setScene(scene);
        stage.show();
    }

    private void updateGroupListView(ListView<String> groupListView) {
        groupListView.getItems().clear();
        for (String groupName : helpSystem.getGroups().keySet()) {
            groupListView.getItems().add(groupName);
        }
    }
    private void showCreateGroupScreen(User user, ListView<String> groupListView) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_LEFT);

        Label titleLabel = new Label("Create New Group");

        TextField groupNameField = new TextField();
        groupNameField.setPromptText("Group Name");

        CheckBox specialAccessCheckBox = new CheckBox("Special Access Group");

        Button createButton = new Button("Create Group");
        Button backButton = new Button("Back");

        createButton.setOnAction(e -> {
            String groupName = groupNameField.getText().trim();
            boolean isSpecialAccess = specialAccessCheckBox.isSelected();

            if (groupName.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Group name cannot be empty.").showAndWait();
                return;
            }

            if (helpSystem.getGroups().containsKey(groupName)) {
                new Alert(Alert.AlertType.ERROR, "Group already exists.").showAndWait();
                return;
            }

            helpSystem.createGroup(groupName, isSpecialAccess, user);

            new Alert(Alert.AlertType.INFORMATION, "Group created successfully!").showAndWait();
            updateGroupListView(groupListView);
            showManageGroups(user);
        });

        backButton.setOnAction(e -> showManageGroups(user));

        root.getChildren().addAll(titleLabel, groupNameField, specialAccessCheckBox, createButton, backButton);
        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void showEditGroupScreen(User user, String groupName, ListView<String> groupListView) {
        // Check if the user is an instructor or admin
        if (!(user.getRoles().contains(User.Role.INSTRUCTOR) || user.getRoles().contains(User.Role.ADMIN))) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Instructors and Admins only.").showAndWait();
            return;
        }

        HelpSystem.Group group = helpSystem.getGroup(groupName);
        if (group == null) {
            new Alert(Alert.AlertType.ERROR, "Group not found.").showAndWait();
            return;
        }

        // Check if the user is a group admin
        if (!group.isGroupAdmin(user)) {
            new Alert(Alert.AlertType.ERROR, "You do not have admin rights for this group.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_LEFT);

        Label titleLabel = new Label("Edit Group: " + groupName);

        ListView<String> memberListView = new ListView<>();
        updateMemberListView(group, memberListView);

        Button addMemberButton = new Button("Add Member");
        Button removeMemberButton = new Button("Remove Member");
        Button backButton = new Button("Back");

        HBox buttonBox = new HBox(10);
        buttonBox.getChildren().addAll(addMemberButton, removeMemberButton, backButton);

        addMemberButton.setOnAction(e -> showAddMemberScreen(user, group, memberListView));
        removeMemberButton.setOnAction(e -> {
            String selectedMember = memberListView.getSelectionModel().getSelectedItem();
            if (selectedMember == null) {
                new Alert(Alert.AlertType.ERROR, "Please select a member to remove.").showAndWait();
                return;
            }
            handleRemoveMember(user, group, selectedMember, memberListView);
        });
        backButton.setOnAction(e -> showManageGroups(user));

        root.getChildren().addAll(titleLabel, memberListView, buttonBox);
        Scene scene = new Scene(root, 500, 500);
        stage.setScene(scene);
        stage.show();
    }


    private void updateMemberListView(HelpSystem.Group group, ListView<String> memberListView) {
        memberListView.getItems().clear();
        // Add group admins
        for (String username : group.getGroupAdmins()) {
            memberListView.getItems().add(username + " (Admin)");
        }
        // Add instructors with view rights
        for (String username : group.getInstructorsWithViewRights()) {
            memberListView.getItems().add(username + " (Instructor)");
        }
        // Add students with view rights
        for (String username : group.getStudentsWithViewRights()) {
            memberListView.getItems().add(username + " (Student)");
        }
        // Add general instructors (for general groups)
        for (String username : group.getInstructors()) {
            memberListView.getItems().add(username + " (Instructor)");
        }
        // Add general students (for general groups)
        for (String username : group.getStudents()) {
            memberListView.getItems().add(username + " (Student)");
        }
    }
    private void showAddMemberScreen(User user, HelpSystem.Group group, ListView<String> memberListView) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_LEFT);

        Label titleLabel = new Label("Add Member to Group: " + group.getName());

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("Admin", "Instructor", "Student");
        roleComboBox.setValue("Student");

        Button addButton = new Button("Add Member");
        Button backButton = new Button("Back");

        addButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String roleStr = roleComboBox.getValue();

            if (username.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Username cannot be empty.").showAndWait();
                return;
            }

            User member = helpSystem.getUser(username);
            if (member == null) {
                new Alert(Alert.AlertType.ERROR, "User not found.").showAndWait();
                return;
            }

            User.GroupRole role;
            try {
                role = User.GroupRole.valueOf(roleStr.toUpperCase());
            } catch (IllegalArgumentException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid role selected.").showAndWait();
                return;
            }

            // Check if adding an admin and ensure that at least one admin remains
            if (role == User.GroupRole.ADMIN && !group.hasAdmin()) {
                // Adding the first admin to the group
                group.addGroupAdmin(member);
            } else if (role == User.GroupRole.INSTRUCTOR) {
                if (group.isSpecialAccessGroup()) {
                    group.addInstructorWithViewRights(member);
                } else {
                    group.addInstructor(member);
                }
            } else if (role == User.GroupRole.STUDENT) {
                if (group.isSpecialAccessGroup()) {
                    group.addStudentWithViewRights(member);
                } else {
                    group.addStudent(member);
                }
            }

            new Alert(Alert.AlertType.INFORMATION, "Member added successfully!").showAndWait();
            updateMemberListView(group, memberListView);
            showEditGroupScreen(user, group.getName(), memberListView);
        });

        backButton.setOnAction(e -> showEditGroupScreen(user, group.getName(), memberListView));

        root.getChildren().addAll(titleLabel, usernameField, roleComboBox, addButton, backButton);
        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void handleRemoveMember(User user, HelpSystem.Group group, String selectedMember, ListView<String> memberListView) {
        String[] parts = selectedMember.split(" ");
        String username = parts[0];
        String rolePart = parts[1]; // e.g., "(Admin)"
        User member = helpSystem.getUser(username);

        if (member == null) {
            new Alert(Alert.AlertType.ERROR, "User not found.").showAndWait();
            return;
        }

        // Remove member based on their role
        if (rolePart.contains("Admin")) {
            if (!group.canRemoveAdmin(member)) {
                new Alert(Alert.AlertType.ERROR, "Cannot remove admin. At least one admin must remain in the group.").showAndWait();
                return;
            }
            group.removeGroupAdmin(member);
        } else if (rolePart.contains("Instructor")) {
            if (group.isSpecialAccessGroup()) {
                group.getInstructorsWithViewRights().remove(username);
                member.removeGroupRole(group.getName());
            } else {
                group.getInstructors().remove(username);
                member.removeGroupRole(group.getName());
            }
        } else if (rolePart.contains("Student")) {
            if (group.isSpecialAccessGroup()) {
                group.getStudentsWithViewRights().remove(username);
                member.removeGroupRole(group.getName());
            } else {
                group.getStudents().remove(username);
                member.removeGroupRole(group.getName());
            }
        }

        new Alert(Alert.AlertType.INFORMATION, "Member removed successfully!").showAndWait();
        updateMemberListView(group, memberListView);
    }
    private void showManageStudents(User user) {
        if (!user.getRoles().contains(User.Role.INSTRUCTOR)) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Instructors only.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Manage Students");

        ListView<String> studentListView = new ListView<>();
        updateStudentListView(studentListView);

        Button addStudentButton = new Button("Add Student");
        Button deleteStudentButton = new Button("Delete Student");
        Button backButton = new Button("Back");

        HBox buttonBox = new HBox(10);
        buttonBox.getChildren().addAll(addStudentButton, deleteStudentButton, backButton);

        addStudentButton.setOnAction(e -> showAddStudentScreen(user, studentListView));

        deleteStudentButton.setOnAction(e -> {
            String selectedStudent = studentListView.getSelectionModel().getSelectedItem();
            if (selectedStudent == null) {
                new Alert(Alert.AlertType.ERROR, "Please select a student to delete.").showAndWait();
                return;
            }
            handleDeleteStudent(user, selectedStudent, studentListView);
        });

        backButton.setOnAction(e -> showDashboard(user));

        root.getChildren().addAll(titleLabel, studentListView, buttonBox);
        Scene scene = new Scene(root, 500, 500);
        stage.setScene(scene);
        stage.show();
    }
    private void updateStudentListView(ListView<String> studentListView) {
        studentListView.getItems().clear();
        for (User user : helpSystem.getUsers().values()) {
            if (user.getRoles().contains(User.Role.STUDENT)) {
                studentListView.getItems().add(user.getUsername());
            }
        }
    }

    private void showAddStudentScreen(User user, ListView<String> studentListView) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label titleLabel = new Label("Add Student");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        Button addButton = new Button("Add Student");
        Button backButton = new Button("Back");

        addButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();
            String email = emailField.getText().trim();

            if (username.isEmpty() || password.isEmpty() || email.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "All fields are required.").showAndWait();
                return;
            }

            if (helpSystem.getUser(username) != null) {
                new Alert(Alert.AlertType.ERROR, "Username already exists.").showAndWait();
                return;
            }

            byte[] passwordHash = authService.hashPassword(password);
            User newUser = new Student(email, username, passwordHash, "FirstName", "LastName");
            newUser.addRole(User.Role.STUDENT);
            helpSystem.addUser(newUser);

            new Alert(Alert.AlertType.INFORMATION, "Student added successfully!").showAndWait();
            updateStudentListView(studentListView);
            showManageStudents(user);
        });

        backButton.setOnAction(e -> showManageStudents(user));

        root.getChildren().addAll(titleLabel, usernameField, passwordField, emailField, addButton, backButton);
        Scene scene = new Scene(root, 400, 400);
        stage.setScene(scene);
        stage.show();
    }
    private void handleDeleteStudent(User user, String selectedStudent, ListView<String> studentListView) {
        User student = helpSystem.getUser(selectedStudent);
        if (student == null) {
            new Alert(Alert.AlertType.ERROR, "User not found.").showAndWait();
            return;
        }

        helpSystem.deleteUser(selectedStudent);
        new Alert(Alert.AlertType.INFORMATION, "Student deleted successfully!").showAndWait();
        updateStudentListView(studentListView);
    }

    private void handleDeleteGroup(User user, String groupName, ListView<String> groupListView) {
        // Check if the user is an instructor or admin
        if (!(user.getRoles().contains(User.Role.INSTRUCTOR) || user.getRoles().contains(User.Role.ADMIN))) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Instructors and Admins only.").showAndWait();
            return;
        }

        HelpSystem.Group group = helpSystem.getGroup(groupName);
        if (group == null) {
            new Alert(Alert.AlertType.ERROR, "Group not found.").showAndWait();
            return;
        }

        // Check if the user is a group admin
        if (!group.isGroupAdmin(user)) {
            new Alert(Alert.AlertType.ERROR, "You do not have admin rights for this group.").showAndWait();
            return;
        }

        // Confirm deletion
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Delete Group");
        confirmAlert.setHeaderText("Are you sure you want to delete the group: " + groupName + "?");
        confirmAlert.setContentText("This action cannot be undone.");

        confirmAlert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                // Remove group from helpSystem
                helpSystem.getGroups().remove(groupName);
                // Remove group references from articles
                for (HelpArticle article : helpSystem.getArticles()) {
                    article.getGroups().remove(groupName);
                }
                // Update group list view
                updateGroupListView(groupListView);
                new Alert(Alert.AlertType.INFORMATION, "Group deleted successfully!").showAndWait();
            }
        });
    }


    

    private void showDashboard(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label welcomeLabel = new Label("Welcome, " + user.getPreferredName() + "!");

        Button manageUsersButton = new Button("Manage Users");
        Button inviteUserButton = new Button("Invite User");
        Button manageArticlesButton = new Button("Manage Help Articles");
        Button searchArticlesButton = new Button("Search Help Articles");
        Button manageGroupsButton = new Button("Manage Groups");
        Button resetPasswordButton = new Button("Reset Password");
        Button deleteAccountButton = new Button("Delete Account");
        Button logoutButton = new Button("Logout");
        Button manageStudentsButton = new Button("Manage Students");

        // Initially hide admin-specific buttons
        manageUsersButton.setVisible(false);
        inviteUserButton.setVisible(false);
        manageArticlesButton.setVisible(false);
        manageGroupsButton.setVisible(false);
        resetPasswordButton.setVisible(false);
        deleteAccountButton.setVisible(false);
        manageStudentsButton.setVisible(false);

        // Show buttons based on user roles
        if (user.getRoles().contains(User.Role.ADMIN)) {
            manageUsersButton.setVisible(true);
            inviteUserButton.setVisible(true);
            manageArticlesButton.setVisible(true);
            manageGroupsButton.setVisible(true);
            resetPasswordButton.setVisible(true);
            deleteAccountButton.setVisible(true);
        } else if (user.getRoles().contains(User.Role.INSTRUCTOR)) {
            manageArticlesButton.setVisible(true);
            manageGroupsButton.setVisible(true);
            manageStudentsButton.setVisible(true); // Show Manage Students button

        }

        // Assign actions to buttons
        manageUsersButton.setOnAction(e -> showManageUsers(user));
        inviteUserButton.setOnAction(e -> showInviteUserScreen(user));
        manageArticlesButton.setOnAction(e -> showManageArticles(user));
        searchArticlesButton.setOnAction(e -> showSearchArticles(user));
        manageGroupsButton.setOnAction(e -> showManageGroups(user));
        resetPasswordButton.setOnAction(e -> showResetPasswordScreen(user));
        deleteAccountButton.setOnAction(e -> showDeleteAccountScreen(user));
        manageStudentsButton.setOnAction(e -> showManageStudents(user));

        logoutButton.setOnAction(e -> {
            helpSystem.setCurrentUser(null);
            showLoginScreen();
        });

        root.getChildren().addAll(welcomeLabel, manageUsersButton, inviteUserButton, manageArticlesButton, searchArticlesButton, manageGroupsButton, manageStudentsButton, resetPasswordButton, deleteAccountButton, logoutButton);
        Scene scene = new Scene(root, 400, 600);
        stage.setScene(scene);
        stage.show();
    }

    private void showManageUsers(User user) {
        if (!user.getRoles().contains(User.Role.ADMIN)) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Admins only.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("Manage Users");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");

        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("Admin", "Instructor", "Student");
        roleComboBox.setValue("Student");

        Button addUserButton = new Button("Add User");
        Button backButton = new Button("Back");

        addUserButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();
            String confirmPassword = confirmPasswordField.getText().trim();
            String email = emailField.getText().trim();
            String role = roleComboBox.getValue();

            if (username.isEmpty() || password.isEmpty() || email.isEmpty() || confirmPassword.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "All fields are required.").showAndWait();
                return;
            }

            if (!password.equals(confirmPassword)) {
                new Alert(Alert.AlertType.ERROR, "Passwords do not match.").showAndWait();
                return;
            }

            if (helpSystem.getUser(username) != null) {
                new Alert(Alert.AlertType.ERROR, "Username already exists.").showAndWait();
                return;
            }

            byte[] passwordHash = authService.hashPassword(password);
            User newUser = null;

            switch (role) {
                case "Admin":
                    newUser = new Admin(email, username, passwordHash, "Admin", "User");
                    break;
                case "Instructor":
                    newUser = new Instructor(email, username, passwordHash, "Instructor", "User");
                    break;
                case "Student":
                    newUser = new Student(email, username, passwordHash, "Student", "User");
                    break;
                default:
                    break;
            }

            if (newUser != null) {
                helpSystem.addUser(newUser);
                new Alert(Alert.AlertType.INFORMATION, "User added successfully!").showAndWait();
                usernameField.clear();
                passwordField.clear();
                confirmPasswordField.clear();
                emailField.clear();
            }
        });

        backButton.setOnAction(e -> showDashboard(user));

        root.getChildren().addAll(title, usernameField, emailField, passwordField, confirmPasswordField, roleComboBox, addUserButton, backButton);
        Scene scene = new Scene(root, 400, 450);
        stage.setScene(scene);
        stage.show();
    }

    private void showInviteUserScreen(User user) {
        if (!user.getRoles().contains(User.Role.ADMIN)) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Admins only.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label prompt = new Label("Invite New User");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("Admin", "Instructor", "Student");
        roleComboBox.setValue("Student");

        Button generateInviteButton = new Button("Generate Invitation Code");
        Button backButton = new Button("Back");

        generateInviteButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String roleStr = roleComboBox.getValue();

            if (username.isEmpty() || roleStr.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Username and role are required.").showAndWait();
                return;
            }

            User.Role role;
            try {
                role = User.Role.valueOf(roleStr.toUpperCase());
            } catch (IllegalArgumentException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid role selected.").showAndWait();
                return;
            }

            String invitationCode = UUID.randomUUID().toString();
            Set<User.Role> roles = new HashSet<>();
            roles.add(role);
            helpSystem.inviteUser(invitationCode, roles);

            // Display the invitation code in an Alert dialog
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Invitation Code Generated");
            alert.setHeaderText(null);
            alert.setContentText("Invitation code generated for " + username + ":\n\n" + invitationCode);
            alert.showAndWait();

            usernameField.clear();
        });

        backButton.setOnAction(e -> showDashboard(user));

        root.getChildren().addAll(prompt, usernameField, roleComboBox, generateInviteButton, backButton);
        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.show();
    }


    private void showResetPasswordScreen(User user) {
        if (!user.getRoles().contains(User.Role.ADMIN)) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Admins only.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label prompt = new Label("Reset User Password");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        Button resetPasswordButton = new Button("Reset Password");
        Button backButton = new Button("Back");

        resetPasswordButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            if (username.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Username is required.").showAndWait();
                return;
            }

            User targetUser = helpSystem.getUser(username);
            if (targetUser != null) {
                // Generate temporary password
                String tempPassword = UUID.randomUUID().toString().substring(0, 8);
                helpSystem.resetPassword(username, tempPassword);
                new Alert(Alert.AlertType.INFORMATION, "Temporary password: " + tempPassword + "\nIt expires in 24 hours.").showAndWait();
                usernameField.clear();
            } else {
                new Alert(Alert.AlertType.ERROR, "User not found.").showAndWait();
            }
        });

        backButton.setOnAction(e -> showDashboard(user));

        root.getChildren().addAll(prompt, usernameField, resetPasswordButton, backButton);
        Scene scene = new Scene(root, 400, 250);
        stage.setScene(scene);
        stage.show();
    }

    private void showDeleteAccountScreen(User user) {
        if (!user.getRoles().contains(User.Role.ADMIN)) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Admins only.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label prompt = new Label("Delete User Account");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        Button deleteButton = new Button("Delete Account");
        Button backButton = new Button("Back");

        deleteButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            if (username.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Username is required.").showAndWait();
                return;
            }

            User targetUser = helpSystem.getUser(username);
            if (targetUser != null) {
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete the account for '" + username + "'?");
                confirmation.showAndWait().ifPresent(response -> {
                    if (response == ButtonType.OK) {
                        helpSystem.deleteUser(username);
                        new Alert(Alert.AlertType.INFORMATION, "User account deleted.").showAndWait();
                        usernameField.clear();
                    }
                });
            } else {
                new Alert(Alert.AlertType.ERROR, "User not found.").showAndWait();
            }
        });

        backButton.setOnAction(e -> showDashboard(user));

        root.getChildren().addAll(prompt, usernameField, deleteButton, backButton);
        Scene scene = new Scene(root, 400, 250);
        stage.setScene(scene);
        stage.show();
    }

    private void showSearchArticles(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Search Help Articles");

        TextField keywordField = new TextField();
        keywordField.setPromptText("Enter keyword(s)");

        ComboBox<String> levelComboBox = new ComboBox<>();
        levelComboBox.getItems().addAll("All", "Beginner", "Intermediate", "Advanced", "Expert");
        levelComboBox.setValue("All");

        TextField groupField = new TextField();
        groupField.setPromptText("Enter group(s) (optional, separated by ';')");

        Button searchButton = new Button("Search");
        Button viewArticleButton = new Button("View Selected Article");
        Button backButton = new Button("Back");

        ListView<String> resultsList = new ListView<>();
        resultsList.setPrefHeight(300);

        searchButton.setOnAction(e -> {
            String keyword = keywordField.getText().trim();
            String level = levelComboBox.getValue();
            String groupsText = groupField.getText().trim();

            List<String> groupList = new ArrayList<>();
            if (!groupsText.isEmpty()) {
                groupList = Arrays.asList(groupsText.split(";"));
            }

            List<HelpArticle> results = helpSystem.searchArticles(keyword, level, groupList, user);

            resultsList.getItems().clear();

            if (results.isEmpty()) {
                resultsList.getItems().add("No articles found for the specified criteria.");
            } else {
                int seqNum = 1;
                for (HelpArticle article : results) {
                    String shortForm = seqNum + ". Title: " + article.getTitle() + ", Level: " + article.getLevel()
                            + ", Groups: " + String.join(", ", article.getGroups());
                    resultsList.getItems().add(shortForm);
                    seqNum++;
                }
            }
        });

        viewArticleButton.setOnAction(e -> {
            String selected = resultsList.getSelectionModel().getSelectedItem();
            if (selected == null || selected.equals("No articles found for the specified criteria.")) {
                new Alert(Alert.AlertType.ERROR, "Please select a valid article to view.").showAndWait();
                return;
            }

            // Extract sequence number from the selected string
            String[] parts = selected.split("\\. ", 2);
            if (parts.length < 2) {
                new Alert(Alert.AlertType.ERROR, "Invalid selection.").showAndWait();
                return;
            }

            int seqNum;
            try {
                seqNum = Integer.parseInt(parts[0]);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid sequence number.").showAndWait();
                return;
            }

            // Get the article from the search results
            String keyword = keywordField.getText().trim();
            String level = levelComboBox.getValue();
            String groupsText = groupField.getText().trim();

            List<String> groupList = new ArrayList<>();
            if (!groupsText.isEmpty()) {
                groupList = Arrays.asList(groupsText.split(";"));
            }

            List<HelpArticle> results = helpSystem.searchArticles(keyword, level, groupList, user);

            if (seqNum < 1 || seqNum > results.size()) {
                new Alert(Alert.AlertType.ERROR, "Invalid sequence number.").showAndWait();
                return;
            }

            HelpArticle article = results.get(seqNum - 1);
            showArticleDetails(article, user);
        });

        backButton.setOnAction(e -> showDashboard(user));

        root.getChildren().addAll(titleLabel, keywordField, levelComboBox, groupField, searchButton, resultsList, viewArticleButton, backButton);
        Scene scene = new Scene(root, 600, 600);
        stage.setScene(scene);
        stage.show();
    }


    
    private void showResetPasswordRequestScreen() {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label prompt = new Label("Reset Password");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New Password");

        PasswordField confirmNewPasswordField = new PasswordField();
        confirmNewPasswordField.setPromptText("Confirm New Password");

        Button resetPasswordButton = new Button("Reset Password");
        Button backButton = new Button("Back");

        resetPasswordButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String newPassword = newPasswordField.getText().trim();
            String confirmNewPassword = confirmNewPasswordField.getText().trim();

            if (username.isEmpty() || newPassword.isEmpty() || confirmNewPassword.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "All fields are required.").showAndWait();
                return;
            }

            if (!newPassword.equals(confirmNewPassword)) {
                new Alert(Alert.AlertType.ERROR, "Passwords do not match.").showAndWait();
                return;
            }

            User userToReset = helpSystem.getUser(username);
            if (userToReset != null) {
                byte[] newHashedPassword = authService.hashPassword(newPassword);
                userToReset.setPasswordHash(newHashedPassword);
                userToReset.setOneTimePassword(false); // Reset one-time password flag
                helpSystem.updateUser(userToReset); // Save the updated user

                new Alert(Alert.AlertType.INFORMATION, "Password reset successfully. Please login with your new password.").showAndWait();
                showLoginScreen();
            } else {
                new Alert(Alert.AlertType.ERROR, "User not found.").showAndWait();
            }
        });

        backButton.setOnAction(e -> showLoginScreen());

        root.getChildren().addAll(prompt, usernameField, newPasswordField, confirmNewPasswordField, resetPasswordButton, backButton);
        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.show();
    }

    // Include the updated showManageArticles method
    private void showArticleDetails(HelpArticle article, User user) {
        if (!helpSystem.userHasAccessToArticle(user, article)) {
            new Alert(Alert.AlertType.ERROR, "You do not have permission to view this article.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_LEFT);

        Label titleLabel = new Label("Title: " + article.getTitle());
        Label descriptionLabel = new Label("Description: " + article.getDescription());
        Label keywordsLabel = new Label("Keywords: " + String.join(", ", article.getKeywords()));
        Label groupsLabel = new Label("Groups: " + String.join(", ", article.getGroups()));
        Label levelLabel = new Label("Level: " + article.getLevel());

        String content;
        if (article.isEncrypted()) {
            // Decrypt content using group's encryption key
            String groupName = article.getGroups().get(0); // Assuming single group
            HelpSystem.Group group = helpSystem.getGroup(groupName);
            if (group != null) {
                content = article.getContent(group.getEncryptionKey());
            } else {
                content = "Cannot decrypt content.";
            }
        } else {
            content = article.getContent(null);
        }

        TextArea contentArea = new TextArea(content);
        contentArea.setEditable(false);
        contentArea.setWrapText(true);
        contentArea.setPrefHeight(300);

        Button backButton = new Button("Back");

        backButton.setOnAction(e -> {
            if (user.getRoles().contains(User.Role.STUDENT)) {
                showStudentDashboard(user);
            } else {
                showDashboard(user);
            }
        });

        root.getChildren().addAll(titleLabel, descriptionLabel, keywordsLabel, groupsLabel, levelLabel, new Label("Content:"), contentArea, backButton);
        Scene scene = new Scene(root, 600, 600);
        stage.setScene(scene);
        stage.show();
    }


    private void showManageArticles(User user) {
        if (!(user.getRoles().contains(User.Role.ADMIN) || user.getRoles().contains(User.Role.INSTRUCTOR))) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Admins and Instructors only.").showAndWait();
            return;
        }

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("Manage Help Articles");

        TextField idField = new TextField();
        idField.setPromptText("ID (for Edit/Delete)");

        TextField titleField = new TextField();
        titleField.setPromptText("Title");

        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Description");

        TextField keywordsField = new TextField();
        keywordsField.setPromptText("Keywords (separated by ';')");

        TextField groupsField = new TextField();
        groupsField.setPromptText("Groups (separated by ';')");

        TextArea contentArea = new TextArea();
        contentArea.setPromptText("Content");
        contentArea.setPrefRowCount(5);

        ComboBox<String> levelComboBox = new ComboBox<>();
        levelComboBox.getItems().addAll("Beginner", "Intermediate", "Advanced", "Expert");
        levelComboBox.setValue("Intermediate");

        Button addArticleButton = new Button("Add Article");
        Button editArticleButton = new Button("Edit Article");
        Button deleteArticleButton = new Button("Delete Article");
        Button listArticlesButton = new Button("List Articles by Group");
        Button backupButton = new Button("Backup Articles");
        Button restoreButton = new Button("Restore Articles");
        Button viewArticleButton = new Button("View Article by ID");
        Button backButton = new Button("Back");

        addArticleButton.setOnAction(e -> {
            String articleTitle = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            String keywordsText = keywordsField.getText().trim();
            String groupsText = groupsField.getText().trim();
            String content = contentArea.getText().trim();
            String level = levelComboBox.getValue();

            if (articleTitle.isEmpty() || description.isEmpty() || keywordsText.isEmpty() || content.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "All fields except ID and groups are required.").showAndWait();
                return;
            }

            List<String> keywords = Arrays.asList(keywordsText.split(";"));
            HelpArticle article = new HelpArticle(articleTitle, description, keywords, content, level, false);

            if (!groupsText.isEmpty()) {
                List<String> groups = Arrays.asList(groupsText.split(";"));
                article.setGroups(groups);
            }

            helpSystem.addArticle(article);

            new Alert(Alert.AlertType.INFORMATION, "Article added successfully! ID: " + article.getId()).showAndWait();
            idField.clear();
            titleField.clear();
            descriptionField.clear();
            keywordsField.clear();
            groupsField.clear();
            contentArea.clear();
            levelComboBox.setValue("Intermediate");
        });

        editArticleButton.setOnAction(e -> {
            String idText = idField.getText().trim();
            if (idText.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "ID is required to edit an article.").showAndWait();
                return;
            }
            long id;
            try {
                id = Long.parseLong(idText);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid ID format.").showAndWait();
                return;
            }
            HelpArticle articleToEdit = helpSystem.getArticleById(id);
            if (articleToEdit != null) {
                // Populate fields with article data for editing
                titleField.setText(articleToEdit.getTitle());
                descriptionField.setText(articleToEdit.getDescription());
                keywordsField.setText(String.join(";", articleToEdit.getKeywords()));
                groupsField.setText(String.join(";", articleToEdit.getGroups()));
                contentArea.setText(articleToEdit.getContent(null)); // Pass null as key
                levelComboBox.setValue(articleToEdit.getLevel());

                // Update the article on save
                addArticleButton.setText("Save Changes");
                addArticleButton.setOnAction(event -> {
                    String articleTitle = titleField.getText().trim();
                    String descriptionText = descriptionField.getText().trim();
                    String keywordsTextNew = keywordsField.getText().trim();
                    String groupsTextNew = groupsField.getText().trim();
                    String contentText = contentArea.getText().trim();
                    String levelText = levelComboBox.getValue();

                    if (articleTitle.isEmpty() || descriptionText.isEmpty() || keywordsTextNew.isEmpty() || contentText.isEmpty()) {
                        new Alert(Alert.AlertType.ERROR, "All fields except ID and groups are required.").showAndWait();
                        return;
                    }

                    List<String> keywordsNew = Arrays.asList(keywordsTextNew.split(";"));
                    articleToEdit.setTitle(articleTitle);
                    articleToEdit.setDescription(descriptionText);
                    articleToEdit.setKeywords(keywordsNew);
                    articleToEdit.setContent(contentText, null); // Pass null as key
                    articleToEdit.setLevel(levelText);

                    if (!groupsTextNew.isEmpty()) {
                        List<String> groupsNew = Arrays.asList(groupsTextNew.split(";"));
                        articleToEdit.setGroups(groupsNew);
                    }

                    helpSystem.updateArticle(articleToEdit);

                    new Alert(Alert.AlertType.INFORMATION, "Article updated successfully!").showAndWait();
                    idField.clear();
                    titleField.clear();
                    descriptionField.clear();
                    keywordsField.clear();
                    groupsField.clear();
                    contentArea.clear();
                    levelComboBox.setValue("Intermediate");
                    addArticleButton.setText("Add Article");
                    // Reset the addArticleButton's action to its original functionality
                    addArticleButton.setOnAction(addArticleButton.getOnAction());
                });
            } else {
                new Alert(Alert.AlertType.ERROR, "Article not found.").showAndWait();
            }
        });

        deleteArticleButton.setOnAction(e -> {
            String idText = idField.getText().trim();
            if (idText.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "ID is required to delete an article.").showAndWait();
                return;
            }
            long id;
            try {
                id = Long.parseLong(idText);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid ID format.").showAndWait();
                return;
            }
            boolean success = helpSystem.deleteArticleById(id);
            if (success) {
                new Alert(Alert.AlertType.INFORMATION, "Article deleted successfully!").showAndWait();
                idField.clear();
            } else {
                new Alert(Alert.AlertType.ERROR, "Article not found.").showAndWait();
            }
        });

        listArticlesButton.setOnAction(e -> showListArticlesByGroup(user));

        backupButton.setOnAction(e -> showBackupArticlesScreen(user));

        restoreButton.setOnAction(e -> showRestoreArticlesScreen(user));

        viewArticleButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("View Article");
            dialog.setHeaderText("Enter the ID of the article you want to view:");
            dialog.setContentText("Article ID:");

            dialog.showAndWait().ifPresent(idStr -> {
                long id;
                try {
                    id = Long.parseLong(idStr.trim());
                } catch (NumberFormatException ex) {
                    new Alert(Alert.AlertType.ERROR, "Invalid ID format.").showAndWait();
                    return;
                }

                HelpArticle article = helpSystem.getArticleById(id);
                if (article != null) {
                    showArticleDetails(article, user); // Pass user as second argument
                } else {
                    new Alert(Alert.AlertType.ERROR, "Article not found.").showAndWait();
                }
            });
        });

        backButton.setOnAction(e -> showDashboard(user));

        root.getChildren().addAll(title, idField, titleField, descriptionField, keywordsField, groupsField, contentArea,
                levelComboBox, addArticleButton, editArticleButton, deleteArticleButton, listArticlesButton,
                backupButton, restoreButton, viewArticleButton, backButton);
        Scene scene = new Scene(root, 500, 700);
        stage.setScene(scene);
        stage.show();
    }
    
    private void showListArticlesByGroup(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("List Articles by Group");

        TextField groupField = new TextField();
        groupField.setPromptText("Enter group(s) separated by ';'");

        Button listButton = new Button("List Articles");
        Button viewArticleButton = new Button("View Selected Article");
        Button backButton = new Button("Back");

        ListView<String> resultsList = new ListView<>();
        resultsList.setPrefHeight(200);

        listButton.setOnAction(e -> {
            String groupsText = groupField.getText().trim();
            if (groupsText.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Please enter at least one group.").showAndWait();
                return;
            }
            List<String> groups = Arrays.asList(groupsText.split(";"));
            List<HelpArticle> results = helpSystem.getArticlesByGroups(groups);
            resultsList.getItems().clear();

            if (results.isEmpty()) {
                resultsList.getItems().add("No articles found for the specified group(s).");
            } else {
                for (HelpArticle article : results) {
                    resultsList.getItems().add(article.getId() + ": " + article.getTitle());
                }
            }
        });

        viewArticleButton.setOnAction(e -> {
            String selected = resultsList.getSelectionModel().getSelectedItem();
            if (selected == null || selected.equals("No articles found for the specified group(s).")) {
                new Alert(Alert.AlertType.ERROR, "Please select a valid article to view.").showAndWait();
                return;
            }

            // Extract ID from the selected string
            String[] parts = selected.split(":");
            if (parts.length < 2) {
                new Alert(Alert.AlertType.ERROR, "Invalid selection.").showAndWait();
                return;
            }

            long id;
            try {
                id = Long.parseLong(parts[0].trim());
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid article ID.").showAndWait();
                return;
            }

            HelpArticle article = helpSystem.getArticleById(id);
            if (article != null) {
                showArticleDetails(article, user); // Pass user as second argument
            } else {
                new Alert(Alert.AlertType.ERROR, "Article not found.").showAndWait();
            }
        });

        backButton.setOnAction(e -> showManageArticles(user));

        root.getChildren().addAll(title, groupField, listButton, resultsList, viewArticleButton, backButton);
        Scene scene = new Scene(root, 500, 500);
        stage.setScene(scene);
        stage.show();
    }
 // This method displays the backup screen where admins and instructors can backup articles
    private void showBackupArticlesScreen(User user) {
        
        if (!(user.getRoles().contains(User.Role.ADMIN) || user.getRoles().contains(User.Role.INSTRUCTOR))) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Admins and Instructors only.").showAndWait();
            return;
        }
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        // Title label for the screen
        Label title = new Label("Backup Articles");

        // Text field for entering the backup file name
        TextField filenameField = new TextField();
        filenameField.setPromptText("Enter filename for backup");

        // Optional text field to specify article groups to backup, separated by semicolons
        TextField groupsField = new TextField();
        groupsField.setPromptText("Enter group(s) to backup (optional, separated by ';')");

        // Button to initiate the backup process
        Button backupButton = new Button("Backup");
        // Button to return to the manage articles screen
        Button backButton = new Button("Back");

        // Event handler for the backup button
        backupButton.setOnAction(e -> {
            // Get the filename from the input field and trim any whitespace
            String filename = filenameField.getText().trim();
            // Get the group names (if any) from the input field and trim any whitespace
            String groupsText = groupsField.getText().trim();

            // If no filename is provided, show an error and exit the method
            if (filename.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Filename is required.").showAndWait();
                return;
            }

            // Parse the groups field if it’s not empty, splitting by semicolons into a list
            List<String> groups = null;
            if (!groupsText.isEmpty()) {
                groups = Arrays.asList(groupsText.split(";"));
            }

            // Call the helpSystem method to perform the backup, providing the filename and optional groups
            helpSystem.backupArticles(filename, groups);
            new Alert(Alert.AlertType.INFORMATION, "Backup completed successfully!").showAndWait();
            filenameField.clear();
            groupsField.clear();
        });

        // Event handler for the back button to return to the manage articles screen
        backButton.setOnAction(e -> showManageArticles(user));

        // Add all components to the layout
        root.getChildren().addAll(title, filenameField, groupsField, backupButton, backButton);
        // Set up and show the scene
        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.show();
    }

 // This method displays the restore screen, allowing admins and instructors to restore articles from a backup
    private void showRestoreArticlesScreen(User user) {
        
        // Check if the user has Admin or Instructor role; if not, show an error message and exit
        if (!(user.getRoles().contains(User.Role.ADMIN) || user.getRoles().contains(User.Role.INSTRUCTOR))) {
            new Alert(Alert.AlertType.ERROR, "Access denied. Admins and Instructors only.").showAndWait();
            return;
        }
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        // Title label for the screen
        Label title = new Label("Restore Articles");

        // Text field for entering the filename to restore from
        TextField filenameField = new TextField();
        filenameField.setPromptText("Enter backup filename");

        // Checkbox to optionally remove existing articles before restore
        CheckBox removeExistingCheckBox = new CheckBox("Remove existing articles before restore");
        removeExistingCheckBox.setSelected(false); // Default to merging articles with existing ones

        // Button to initiate the restore process
        Button restoreButton = new Button("Restore");
        // Button to return to the manage articles screen
        Button backButton = new Button("Back");

        // Event handler for the restore button
        restoreButton.setOnAction(e -> {
            // Get the filename from the input field and trim any whitespace
            String filename = filenameField.getText().trim();

            // If no filename is provided, show an error and exit the method
            if (filename.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Filename is required.").showAndWait();
                return;
            }

            // Check if existing articles should be removed before restoring from backup
            boolean removeExisting = removeExistingCheckBox.isSelected();

            // Call the helpSystem method to perform the restore operation
            helpSystem.restoreArticles(filename, removeExisting);

            // Show confirmation message and clear the input fields
            new Alert(Alert.AlertType.INFORMATION, "Restore completed successfully!").showAndWait();
            filenameField.clear();
            removeExistingCheckBox.setSelected(false); // Reset to default
        });

        backButton.setOnAction(e -> showManageArticles(user));
        root.getChildren().addAll(title, filenameField, removeExistingCheckBox, restoreButton, backButton);
        // Set up and show the scene
        Scene scene = new Scene(root, 400, 350);
        stage.setScene(scene);
        stage.show();	
    }
    
    private void showStudentSearchArticles(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Search Help Articles");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField keywordField = new TextField();
        keywordField.setPromptText("Enter keyword(s)");

        ComboBox<String> levelComboBox = new ComboBox<>();
        levelComboBox.getItems().addAll("All", "Beginner", "Intermediate", "Advanced", "Expert");
        levelComboBox.setValue("All");

        TextField groupField = new TextField();
        groupField.setPromptText("Enter group(s) (optional, separated by ';')");

        Button searchButton = new Button("Search");
        Button viewArticleButton = new Button("View Selected Article");
        Button sendGenericMessageButton = new Button("Send Generic Message");
        Button sendSpecificMessageButton = new Button("Send Specific Message");
        Button backButton = new Button("Back");

        ListView<String> resultsList = new ListView<>();
        resultsList.setPrefHeight(200);

        searchButton.setOnAction(e -> {
            String keyword = keywordField.getText().trim();
            String level = levelComboBox.getValue();
            String groupsText = groupField.getText().trim();

            List<String> groupList = new ArrayList<>();
            if (!groupsText.isEmpty()) {
                groupList = Arrays.asList(groupsText.split(";"));
            }

            List<HelpArticle> results = helpSystem.searchArticles(keyword, level, groupList, user);

            // Record the student's search query
            helpSystem.addStudentSearch(user.getUsername(), keyword);

            resultsList.getItems().clear();

            // Display current group
            String currentGroup = groupsText.isEmpty() ? "All" : groupsText;
            resultsList.getItems().add("Current Group: " + currentGroup);

            // Count articles per level
            Map<String, Integer> levelCounts = new HashMap<>();
            for (HelpArticle article : results) {
                levelCounts.put(article.getLevel(), levelCounts.getOrDefault(article.getLevel(), 0) + 1);
            }
            for (String lvl : Arrays.asList("Beginner", "Intermediate", "Advanced", "Expert")) {
                int count = levelCounts.getOrDefault(lvl, 0);
                resultsList.getItems().add("Level " + lvl + ": " + count + " articles");
            }

            // List articles in short form
            if (results.isEmpty()) {
                resultsList.getItems().add("No articles found for the specified criteria.");
            } else {
                int seqNum = 1;
                for (HelpArticle article : results) {
                    String shortForm = seqNum + ". Title: " + article.getTitle() + ", Description: " + article.getDescription();
                    resultsList.getItems().add(shortForm);
                    seqNum++;
                }
            }
        });

        viewArticleButton.setOnAction(e -> {
            String selected = resultsList.getSelectionModel().getSelectedItem();
            if (selected == null || selected.equals("No articles found for the specified criteria.")) {
                new Alert(Alert.AlertType.ERROR, "Please select a valid article to view.").showAndWait();
                return;
            }

            // Extract sequence number from the selected string
            String[] parts = selected.split("\\. ", 2);
            if (parts.length < 2) {
                new Alert(Alert.AlertType.ERROR, "Invalid selection.").showAndWait();
                return;
            }

            int seqNum;
            try {
                seqNum = Integer.parseInt(parts[0]);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid sequence number.").showAndWait();
                return;
            }

            // Get the article from the search results
            String keyword = keywordField.getText().trim();
            String level = levelComboBox.getValue();
            String groupsText = groupField.getText().trim();

            List<String> groupList = new ArrayList<>();
            if (!groupsText.isEmpty()) {
                groupList = Arrays.asList(groupsText.split(";"));
            }

            List<HelpArticle> results = helpSystem.searchArticles(keyword, level, groupList, user);

            if (seqNum < 1 || seqNum > results.size()) {
                new Alert(Alert.AlertType.ERROR, "Invalid sequence number.").showAndWait();
                return;
            }

            HelpArticle article = results.get(seqNum - 1);
            showArticleDetails(article, user);
        });

        sendGenericMessageButton.setOnAction(event -> showSendGenericMessageScreen(user));
        sendSpecificMessageButton.setOnAction(event -> showSendSpecificMessageScreen(user));
        backButton.setOnAction(e -> showStudentDashboard(user));

        // Group send buttons in an HBox for better layout
        HBox messageButtonsBox = new HBox(10);
        messageButtonsBox.setAlignment(Pos.CENTER);
        messageButtonsBox.getChildren().addAll(sendGenericMessageButton, sendSpecificMessageButton);

        // Add all components to the VBox
        root.getChildren().addAll(
            titleLabel,
            keywordField,
            levelComboBox,
            groupField,
            searchButton,
            resultsList,
            viewArticleButton,
            messageButtonsBox, // Add HBox containing message buttons
            backButton
        );

        Scene scene = new Scene(root, 600, 600);
        stage.setScene(scene);
        stage.show();
    }



    
    private void showSendGenericMessageScreen(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Send Generic Message");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        TextArea messageArea = new TextArea();
        messageArea.setPromptText("Enter your message here...");
        messageArea.setPrefRowCount(10);

        Button sendButton = new Button("Send");
        Button backButton = new Button("Back");

        sendButton.setOnAction(e -> {
            String message = messageArea.getText().trim();
            if (message.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Message cannot be empty.").showAndWait();
                return;
            }

            helpSystem.addGenericMessage(user.getUsername(), message);
            new Alert(Alert.AlertType.INFORMATION, "Generic message sent successfully!").showAndWait();
            messageArea.clear();
        });

        backButton.setOnAction(e -> showStudentSearchArticles(user));

        root.getChildren().addAll(titleLabel, messageArea, sendButton, backButton);
        Scene scene = new Scene(root, 500, 400);
        stage.setScene(scene);
        stage.show();
    }

    private void showSendSpecificMessageScreen(User user) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Send Specific Message");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        TextField articleIdField = new TextField();
        articleIdField.setPromptText("Enter Article ID");

        TextArea messageArea = new TextArea();
        messageArea.setPromptText("Enter your specific message here...");
        messageArea.setPrefRowCount(10);

        Button sendButton = new Button("Send");
        Button backButton = new Button("Back");

        sendButton.setOnAction(e -> {
            String articleIdText = articleIdField.getText().trim();
            String message = messageArea.getText().trim();

            if (articleIdText.isEmpty() || message.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Both Article ID and message are required.").showAndWait();
                return;
            }

            long articleId;
            try {
                articleId = Long.parseLong(articleIdText);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Invalid Article ID format.").showAndWait();
                return;
            }

            HelpArticle article = helpSystem.getArticleById(articleId);
            if (article == null) {
                new Alert(Alert.AlertType.ERROR, "Article not found.").showAndWait();
                return;
            }

            helpSystem.addSpecificMessage(user.getUsername(), articleId, message);
            new Alert(Alert.AlertType.INFORMATION, "Specific message sent successfully!").showAndWait();
            articleIdField.clear();
            messageArea.clear();
        });

        backButton.setOnAction(e -> showStudentSearchArticles(user));

        root.getChildren().addAll(titleLabel, articleIdField, messageArea, sendButton, backButton);
        Scene scene = new Scene(root, 500, 450);
        stage.setScene(scene);
        stage.show();
    }


    
    
    

    
}