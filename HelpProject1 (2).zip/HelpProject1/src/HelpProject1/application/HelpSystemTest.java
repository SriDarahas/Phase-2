package HelpProject1.application;

import java.util.Arrays;

import java.util.List;

public class HelpSystemTest {

    public static void main(String[] args) {
    	HelpSystem helpSystem = new HelpSystem();
    	byte[] passwordHash = new byte[]{/* your hash here */};
        User testUser = new User("test@example.com", "testuser", passwordHash, "Test", "User");
        testUser.addRole(User.Role.INSTRUCTOR);
        helpSystem.addUser(testUser);

        // Create a group with the test user as creator
        helpSystem.createGroup("TestGroup", false, testUser);

        HelpSystemTest tester = new HelpSystemTest();
        tester.testEncryptionDecryption();
        tester.testGroupPermissions();
        tester.testStudentSearchesAndMessages();
        
    }

    public void testEncryptionDecryption() {
        System.out.println("Running testEncryptionDecryption...");
        String content = "This is a secret content.";
        String key = "testkey123456789"; // Ensure key is 16 bytes for AES

        HelpArticle article = new HelpArticle("Title", "Description", Arrays.asList("keyword"), "", "Intermediate", true);
        article.setContent(content, key);

        String decryptedContent = article.getContent(key);

        if (content.equals(decryptedContent)) {
            System.out.println("testEncryptionDecryption PASSED");
        } else {
            System.out.println("testEncryptionDecryption FAILED");
            System.out.println("Expected: " + content);
            System.out.println("Actual: " + decryptedContent);
        }
    }

    public void testGroupPermissions() {
        System.out.println("\nRunning testGroupPermissions...");
        HelpSystem helpSystem = new HelpSystem();
        User student = new User("student1", AuthService.hashStaticPassword("password"));
        student.addRole(User.Role.STUDENT);
        User instructor = new User("instructor1", AuthService.hashStaticPassword("password"));
        instructor.addRole(User.Role.INSTRUCTOR);

        helpSystem.addUser(student);
        helpSystem.addUser(instructor);

        helpSystem.createGroup("SpecialGroup", true,instructor);
        HelpSystem.Group group = helpSystem.getGroup("SpecialGroup");

        helpSystem.addUserToGroup("SpecialGroup", instructor, User.GroupRole.INSTRUCTOR);
        helpSystem.addUserToGroup("SpecialGroup", student, User.GroupRole.STUDENT);

        HelpArticle article = new HelpArticle("Secret Title", "Secret Description", Arrays.asList("secret"), "Secret Content", "Advanced", true);
        helpSystem.addArticleToGroup("SpecialGroup", article);

        boolean studentHasAccess = helpSystem.userHasAccessToArticle(student, article);
        boolean instructorHasAccess = helpSystem.userHasAccessToArticle(instructor, article);

        // Simulate another student who is not part of the group
        User outsider = new User("outsider", AuthService.hashStaticPassword("password"));
        outsider.addRole(User.Role.STUDENT);
        helpSystem.addUser(outsider);

        boolean outsiderHasAccess = helpSystem.userHasAccessToArticle(outsider, article);

        if (studentHasAccess && instructorHasAccess && !outsiderHasAccess) {
            System.out.println("testGroupPermissions PASSED");
        } else {
            System.out.println("testGroupPermissions FAILED");
            System.out.println("studentHasAccess: " + studentHasAccess);
            System.out.println("instructorHasAccess: " + instructorHasAccess);
            System.out.println("outsiderHasAccess: " + outsiderHasAccess);
        }
    }

    public void testStudentSearchesAndMessages() {
        System.out.println("\nRunning testStudentSearchesAndMessages...");
        HelpSystem helpSystem = new HelpSystem();
        User student = new User("student1", AuthService.hashStaticPassword("password"));
        student.addRole(User.Role.STUDENT);
        helpSystem.addUser(student);

        helpSystem.addStudentSearch(student.getUsername(), "OOP Concepts");
        helpSystem.addStudentSearch(student.getUsername(), "Design Patterns");

        List<String> searches = helpSystem.getStudentSearches(student.getUsername());

        boolean searchesCorrect = searches.size() == 2 &&
                "OOP Concepts".equals(searches.get(0)) &&
                "Design Patterns".equals(searches.get(1));

        helpSystem.addStudentMessage(student.getUsername(), "I need help with Singleton Pattern.");
        List<String> messages = helpSystem.getStudentMessages(student.getUsername());

        boolean messagesCorrect = messages.size() == 1 &&
                "I need help with Singleton Pattern.".equals(messages.get(0));

        if (searchesCorrect && messagesCorrect) {
            System.out.println("testStudentSearchesAndMessages PASSED");
        } else {
            System.out.println("testStudentSearchesAndMessages FAILED");
            System.out.println("Searches: " + searches);
            System.out.println("Messages: " + messages);
        }
    }
}
